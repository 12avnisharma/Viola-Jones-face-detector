clc;
clear all;
path1='C:\Users\avnis\OneDrive - Michigan State University\Desktop\CVHW3\New folder\Testing\test\images';
cd(path1);
testimages=dir('*.jpg');
m=0;
for i=1:length(testimages)
    m=m+1;
    ii=imread(testimages(i).name);
    str = convertCharsToStrings(testimages(i).name);
    disp(str);
    rec=textfile(str);
    detect=detectFaces(ii)
   %rec=textfile('103.jpg');
   for k =1:length(rec)
       m=m+1;
       reccells1=rec(1,k);
       rect1=cell2mat(reccells1);
       new=split(rect1);
       rect2=str2double(new);
       Int1=imcrop(ii,rect2);
       thisFileName = sprintf('C:/Users/avnis/OneDrive - Michigan State University/Desktop/CVHW3/New folder/Testing/test/Rectangulartestimgs/%d.png',m+300);
       %fullFileName = fullfile(pwd, thisFileName);
       imwrite(Int1, thisFileName);
   end
   end