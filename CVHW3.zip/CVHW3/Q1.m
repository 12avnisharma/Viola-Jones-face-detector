clc;
clear all;
image =imread('sample2.jpg'); 
subplot(2,1,1); 
imshow(image); 
title('Input image');
subplot(2,1,2);
imhist(image,64)
title('RGB image histogram');