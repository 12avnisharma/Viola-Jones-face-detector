This dataset is a small subset from the Face Detection Data Set and Benchmark (FDDB)
It is used for CSE830 Computer Vision Course at Michigan State University, 2019 Fall. 

--------------------------------
1. Contents
- train
   images/: include 300 images for training, each image containing 1-10 faces, 533 faces in total. 
   bbox.txt: bbox annotations for all images in the training set

- test
   images/: include 150 images for testing, each image containing 1-10 faces, 253 faces in total. 
   bbox.txt: bbox annotations for all images in the testing set

--------------------------------
2. bbox annotations
   bbox.txt has the following format: 

   image filename
   N (the number of faces in current image)
   bbox for face 1
   boox for face 2
   ...
   bbox for face N

   Here, each face bounding box is denoted by:
   <x_left y_top width height>

---------------------------------
3. Training face detector
   - Use the bbox annotations in the training set to locate faces as the positive samples. 
   - Select the negative non-face samples from the background without overlap with the bounding boxes. 
   - You could use a full/subset of the training set to train your algorithm and test on the testing set. 

