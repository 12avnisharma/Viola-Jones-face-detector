function rec=q2images(name)
%filename='C:\Users\avnis\OneDrive - Michigan State University\Desktop\CVHW3\cse803_Hw3_prob3_dataset\dataset\train';
fid=fopen('bbox.txt');
while ~feof(fid)
    S=textscan(fid,'%s','delimiter','\n');
end
for i=1:1185
    basefilename=sprintf('train/images/%s',name);
    if(strcmp(S{1,1}{i,1},basefilename))
        c=0;
        rec={};
        size=S{1,1}{i+1,1};
        c=i+2;
        for j=c:c+str2num(size)-1
            rec=[rec S{1,1}{j,1}];
        end
    end
end
fclose(fid);
end