
function crop
path1='C:\Users\avnis\OneDrive - Michigan State University\Desktop\CVHW3\cse803_Hw3_prob3_dataset\dataset\train\images';
cd(path1);
trainimages=dir('*.jpg');
m=0;
for i=1:length(trainimages)
    ii=imread(trainimages(i).name);
    str = convertCharsToStrings(trainimages(i).name);
    disp(str);
    rec=q2images(str);
   %rec=textfile('103.jpg');
   for k =1:length(rec)
       m=m+1;
       reccells1=rec(1,k);
       rect1=cell2mat(reccells1);
       new=split(rect1);
       rect2=str2double(new);
       Int1=imcrop(ii,rect2);
        I2 = imresize(Int1,[100 100]); 
        if size(I2,3)==3
        In=rgb2gray(I2); % use i2f the image containing RGB value 
        else
            In=I2;
        end
        thisFileName = sprintf('C:/Users/avnis/OneDrive - Michigan State University/Desktop/CVHW3/New folder/weirdsize/%d.png',m);
       %fullFileName = fullfile(pwd, thisFileName);
       imwrite(In, thisFileName);
   end
end
end
   %for k=1:length(rec)
        %disp(k);
        %disp(rec{1,1}{k,1});
        %disp(reccells);
       % reccells={};
        %{
        for j=1:length(reccells)
           
            disp(j);
           
            rect1=cell2mat(reccells(1,j));
            new=split(rect1);
            rect2=str2double(new);
            Int1=imcrop(ii,rect2);
            %path2=;
            %cd(path2)
            thisFileName = sprintf('/home/achsah/Documents/Computer_Vision_solutions/homework3/Faces/Face#%d.png',m);
            %fullFileName = fullfile(pwd, thisFileName);
            imwrite(Int1, thisFileName);
            %reccells={};
            %}
        %end  
       % rec = {};
   % end