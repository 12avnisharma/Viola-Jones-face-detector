clc;
clear all;

detect=detectFaces('427.jpg')